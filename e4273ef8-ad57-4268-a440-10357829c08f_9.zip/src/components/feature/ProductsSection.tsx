
import { useState } from 'react';
import Button from '../base/Button';

interface ProductCardProps {
  name: string;
  specs: string;
  features: string[];
  image: string;
  badge?: string;
}

function ProductCard({ name, specs, features, image, badge }: ProductCardProps) {
  const handleWhatsAppContact = () => {
    const message = `Gostaria de saber mais sobre a ${name}`;
    const whatsappUrl = `http://wa.me/551141651062?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  return (
    <div className="bg-gray-900/40 backdrop-blur-sm rounded-3xl border border-gray-800/30 overflow-hidden hover:border-gray-700/50 transition-all duration-700 cursor-pointer group transform hover:scale-105 hover:-translate-y-3 active:scale-95 relative" data-product-shop="true">
      {badge && (
        <div className="absolute top-4 sm:top-6 left-4 sm:left-6 bg-gradient-to-r from-blue-500 to-purple-500 text-white px-3 sm:px-4 py-1 sm:py-2 rounded-full text-xs sm:text-sm font-medium z-10">
          {badge}
        </div>
      )}
      
      <div className="aspect-square bg-gradient-to-br from-gray-800 to-gray-900 p-6 sm:p-8 relative overflow-hidden">
        <div className="absolute top-4 sm:top-6 right-4 sm:right-6 w-8 h-8 sm:w-10 sm:h-10 bg-white/10 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-500 transform translate-x-3 group-hover:translate-x-0">
          <i className="ri-heart-line text-white text-sm sm:text-lg"></i>
        </div>
        <img 
          alt={name}
          className="w-full h-full object-cover object-top rounded-2xl transition-transform duration-700 group-hover:scale-110 group-hover:rotate-12" 
          src={image}
        />
      </div>
      
      <div className="p-6 sm:p-8">
        <h3 className="text-lg sm:text-xl font-medium text-white mb-2 sm:mb-3 group-hover:text-gray-100 transition-colors duration-300">
          {name}
        </h3>
        <p className="text-gray-400 mb-3 sm:mb-4 font-light text-sm sm:text-base group-hover:text-gray-300 transition-colors duration-300">
          {specs}
        </p>
        
        <ul className="space-y-2 mb-6 sm:mb-8">
          {features.map((feature, index) => (
            <li key={index} className="flex items-center text-gray-500 group-hover:text-gray-400 transition-colors duration-300">
              <i className="ri-check-line text-green-400 mr-3 text-sm"></i>
              <span className="text-xs sm:text-sm font-light">{feature}</span>
            </li>
          ))}
        </ul>
        
        <Button variant="primary" fullWidth onClick={handleWhatsAppContact}>
          Entrar em Contato
        </Button>
      </div>
    </div>
  );
}

export default function ProductsSection() {
  const [activeCategory, setActiveCategory] = useState('auto');

  const categories = [
    { id: 'auto', name: 'Automóveis', shortName: 'Auto', icon: 'ri-car-line' },
    { id: 'moto', name: 'Motocicletas', shortName: 'Moto', icon: 'ri-motorbike-line' },
    { id: 'pesado', name: 'Caminhão/ônibus', shortName: 'Pesado', icon: 'ri-truck-line' },
    { id: 'mais', name: '...Mais', shortName: 'Mais', icon: 'ri-more-line' }
  ];

  const productsByCategory = {
    auto: [
      {
        name: 'Bateria Cunha Auto 60Ah',
        specs: '12V • 60Ah • 500A',
        features: ['Garantia 36 meses', 'Instalação gratuita', 'Tecnologia premium'],
        image: 'https://readdy.ai/api/search-image?query=automotive%20car%20battery%20with%20sleek%20black%20design%20and%20blue%20accents%2C%20professional%20product%20photography%20with%20soft%20shadows%20on%20dark%20background%2C%20premium%20car%20battery%20for%20vehicles%2C%20clean%20geometric%20design&width=400&height=400&seq=auto-battery-60ah&orientation=squarish',
        badge: 'Mais Vendido'
      },
      {
        name: 'Bateria Cunha Auto 70Ah',
        specs: '12V • 70Ah • 600A',
        features: ['Alta performance', 'Resistência total', 'Garantia 48 meses'],
        image: 'https://readdy.ai/api/search-image?query=automotive%20car%20battery%20with%20sleek%20black%20design%20and%20silver%20accents%2C%20professional%20product%20photography%20with%20soft%20shadows%20on%20dark%20background%2C%20premium%20car%20battery%20for%20vehicles%2C%20clean%20geometric%20design&width=400&height=400&seq=auto-battery-70ah&orientation=squarish'
      },
      {
        name: 'Bateria Cunha Auto Pro 80Ah',
        specs: '12V • 80Ah • 750A',
        features: ['Tecnologia Premium', 'Máxima durabilidade', 'Garantia 60 meses'],
        image: 'https://readdy.ai/api/search-image?query=automotive%20car%20battery%20with%20sleek%20black%20design%20and%20gold%20accents%2C%20professional%20product%20photography%20with%20soft%20shadows%20on%20dark%20background%2C%20premium%20car%20battery%20for%20vehicles%2C%20clean%20geometric%20design&width=400&height=400&seq=auto-pro-battery-80ah&orientation=squarish',
        badge: 'Premium'
      }
    ],
    moto: [
      {
        name: 'Bateria Cunha Moto 7Ah',
        specs: '12V • 7Ah • 120A',
        features: ['Compacta e potente', 'Resistente a vibração', 'Garantia 24 meses'],
        image: 'https://readdy.ai/api/search-image?query=motorcycle%20battery%20compact%20design%20with%20red%20accents%2C%20professional%20product%20photography%20with%20soft%20shadows%20on%20dark%20background%2C%20premium%20motorcycle%20battery%20for%20bikes%2C%20clean%20geometric%20design&width=400&height=400&seq=moto-battery-7ah&orientation=squarish',
        badge: 'Mais Vendido'
      },
      {
        name: 'Bateria Cunha Moto 9Ah',
        specs: '12V • 9Ah • 150A',
        features: ['Alta durabilidade', 'Tecnologia AGM', 'Garantia 30 meses'],
        image: 'https://readdy.ai/api/search-image?query=motorcycle%20battery%20compact%20design%20with%20orange%20accents%2C%20professional%20product%20photography%20with%20soft%20shadows%20on%20dark%20background%2C%20premium%20motorcycle%20battery%20for%20bikes%2C%20clean%20geometric%20design&width=400&height=400&seq=moto-battery-9ah&orientation=squarish'
      },
      {
        name: 'Bateria Cunha Moto Pro 12Ah',
        specs: '12V • 12Ah • 200A',
        features: ['Performance superior', 'Máxima potência', 'Garantia 36 meses'],
        image: 'https://readdy.ai/api/search-image?query=motorcycle%20battery%20compact%20design%20with%20yellow%20accents%2C%20professional%20product%20photography%20with%20soft%20shadows%20on%20dark%20background%2C%20premium%20motorcycle%20battery%20for%20bikes%2C%20clean%20geometric%20design&width=400&height=400&seq=moto-pro-battery-12ah&orientation=squarish',
        badge: 'Premium'
      }
    ],
    pesado: [
      {
        name: 'Bateria Cunha Pesado 150Ah',
        specs: '12V • 150Ah • 1000A',
        features: ['Extra resistente', 'Para uso intenso', 'Garantia 48 meses'],
        image: 'https://readdy.ai/api/search-image?query=heavy%20duty%20truck%20battery%20large%20size%20with%20green%20accents%2C%20professional%20product%20photography%20with%20soft%20shadows%20on%20dark%20background%2C%20premium%20truck%20battery%20for%20commercial%20vehicles%2C%20clean%20geometric%20design&width=400&height=400&seq=pesado-battery-150ah&orientation=squarish',
        badge: 'Mais Vendido'
      },
      {
        name: 'Bateria Cunha Pesado 180Ah',
        specs: '12V • 180Ah • 1200A',
        features: ['Máxima capacidade', 'Tecnologia avançada', 'Garantia 60 meses'],
        image: 'https://readdy.ai/api/search-image?query=heavy%20duty%20truck%20battery%20large%20size%20with%20purple%20accents%2C%20professional%20product%20photography%20with%20soft%20shadows%20on%20dark%20background%2C%20premium%20truck%20battery%20for%20commercial%20vehicles%2C%20clean%20geometric%20design&width=400&height=400&seq=pesado-battery-180ah&orientation=squarish'
      },
      {
        name: 'Bateria Cunha Pesado Pro 220Ah',
        specs: '12V • 220Ah • 1500A',
        features: ['Performance extrema', 'Uso profissional', 'Garantia 72 meses'],
        image: 'https://readdy.ai/api/search-image?query=heavy%20duty%20truck%20battery%20large%20size%20with%20cyan%20accents%2C%20professional%20product%20photography%20with%20soft%20shadows%20on%20dark%20background%2C%20premium%20truck%20battery%20for%20commercial%20vehicles%2C%20clean%20geometric%20design&width=400&height=400&seq=pesado-pro-battery-220ah&orientation=squarish',
        badge: 'Premium'
      }
    ],
    mais: [
      {
        name: 'Bateria Cunha Auto 60Ah',
        specs: '12V • 60Ah • 500A',
        features: ['Garantia 36 meses', 'Instalação gratuita', 'Tecnologia premium'],
        image: 'https://readdy.ai/api/search-image?query=automotive%20car%20battery%20with%20sleek%20black%20design%20and%20blue%20accents%2C%20professional%20product%20photography%20with%20soft%20shadows%20on%20dark%20background%2C%20premium%20car%20battery%20for%20vehicles%2C%20clean%20geometric%20design&width=400&height=400&seq=auto-battery-60ah-mais&orientation=squarish',
        badge: 'Mais Vendido'
      },
      {
        name: 'Bateria Cunha Auto 70Ah',
        specs: '12V • 70Ah • 600A',
        features: ['Alta performance', 'Resistência total', 'Garantia 48 meses'],
        image: 'https://readdy.ai/api/search-image?query=automotive%20car%20battery%20with%20sleek%20black%20design%20and%20silver%20accents%2C%20professional%20product%20photography%20with%20soft%20shadows%20on%20dark%20background%2C%20premium%20car%20battery%20for%20vehicles%2C%20clean%20geometric%20design&width=400&height=400&seq=auto-battery-70ah-mais&orientation=squarish'
      },
      {
        name: 'Bateria Cunha Auto Pro 80Ah',
        specs: '12V • 80Ah • 750A',
        features: ['Tecnologia Premium', 'Máxima durabilidade', 'Garantia 60 meses'],
        image: 'https://readdy.ai/api/search-image?query=automotive%20car%20battery%20with%20sleek%20black%20design%20and%20gold%20accents%2C%20professional%20product%20photography%20with%20soft%20shadows%20on%20dark%20background%2C%20premium%20car%20battery%20for%20vehicles%2C%20clean%20geometric%20design&width=400&height=400&seq=auto-pro-battery-80ah-mais&orientation=squarish',
        badge: 'Premium'
      }
    ]
  };

  const handleMoreClick = () => {
    window.REACT_APP_NAVIGATE('/produtos');
  };

  return (
    <section id="produtos" className="py-16 sm:py-24 lg:py-32 bg-black relative overflow-hidden" data-product-shop="true">
      {/* Background effects */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-1/3 left-1/4 w-80 h-80 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/3 right-1/4 w-80 h-80 bg-gradient-to-r from-blue-600 to-cyan-600 rounded-full blur-3xl animate-pulse"></div>
      </div>
      
      <div className="container mx-auto px-4 sm:px-6 relative z-10">
        <div className="text-center mb-16 sm:mb-24">
          <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-thin text-white mb-6 sm:mb-8 tracking-tight">
            Um Pouco dos Nossos Produtos
          </h2>
          <p className="text-base sm:text-lg md:text-xl text-gray-400 max-w-3xl mx-auto font-light leading-relaxed px-4">
            Linha completa de baterias premium com tecnologia avançada e design sofisticado
          </p>
        </div>
        
        {/* Category tabs */}
        <div className="flex justify-center mb-12 sm:mb-20">
          <div className="bg-gray-800/40 backdrop-blur-sm p-2 rounded-full border border-gray-700/30 overflow-x-auto">
            <div className="flex space-x-2">
              {categories.map((category) => (
                <button
                  key={category.id}
                  onClick={() => {
                    if (category.id === 'mais') {
                      handleMoreClick();
                    } else {
                      setActiveCategory(category.id);
                    }
                  }}
                  className={`px-4 sm:px-6 lg:px-10 py-3 sm:py-4 rounded-full transition-all duration-500 whitespace-nowrap cursor-pointer font-medium text-sm sm:text-base lg:text-lg transform hover:scale-105 active:scale-95 ${
                    activeCategory === category.id
                      ? 'bg-white text-black shadow-2xl scale-105'
                      : 'text-gray-400 hover:text-white hover:bg-gray-700/50'
                  }`}
                >
                  <i className={`${category.icon} mr-2 sm:mr-3 transition-transform duration-500 ${
                    activeCategory === category.id ? 'rotate-12 scale-110' : ''
                  }`}></i>
                  <span className="hidden sm:inline">{category.name}</span>
                  <span className="sm:hidden">{category.shortName}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
        
        {/* Products grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8 lg:gap-10">
          {productsByCategory[activeCategory as keyof typeof productsByCategory].map((product, index) => (
            <ProductCard key={index} {...product} />
          ))}
        </div>
      </div>
    </section>
  );
}
