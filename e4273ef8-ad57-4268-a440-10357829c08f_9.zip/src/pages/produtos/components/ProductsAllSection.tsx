
import { useState } from 'react';
import Button from '../../../components/base/Button';

interface ProductCardProps {
  name: string;
  specs: string;
  features: string[];
  image: string;
  badge?: string;
}

function ProductCard({ name, specs, features, image, badge }: ProductCardProps) {
  const handleWhatsAppContact = () => {
    const message = `Gostaria de saber mais sobre a ${name}`;
    const whatsappUrl = `http://wa.me/551141651062?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  return (
    <div className="bg-gray-900/40 backdrop-blur-sm rounded-3xl border border-gray-800/30 overflow-hidden hover:border-gray-700/50 transition-all duration-700 cursor-pointer group transform hover:scale-105 hover:-translate-y-3 active:scale-95 relative" data-product-shop="true">
      {badge && (
        <div className="absolute top-4 sm:top-6 left-4 sm:left-6 bg-gradient-to-r from-blue-500 to-purple-500 text-white px-3 sm:px-4 py-1 sm:py-2 rounded-full text-xs sm:text-sm font-medium z-10">
          {badge}
        </div>
      )}
      
      <div className="aspect-square bg-gradient-to-br from-gray-800 to-gray-900 p-6 sm:p-8 relative overflow-hidden">
        <div className="absolute top-4 sm:top-6 right-4 sm:right-6 w-8 h-8 sm:w-10 sm:h-10 bg-white/10 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-500 transform translate-x-3 group-hover:translate-x-0">
          <i className="ri-heart-line text-white text-sm sm:text-lg"></i>
        </div>
        <img 
          alt={name}
          className="w-full h-full object-cover object-top rounded-2xl transition-transform duration-700 group-hover:scale-110 group-hover:rotate-12" 
          src={image}
        />
      </div>
      
      <div className="p-6 sm:p-8">
        <h3 className="text-lg sm:text-xl font-medium text-white mb-2 sm:mb-3 group-hover:text-gray-100 transition-colors duration-300">
          {name}
        </h3>
        <p className="text-gray-400 mb-3 sm:mb-4 font-light text-sm sm:text-base group-hover:text-gray-300 transition-colors duration-300">
          {specs}
        </p>
        
        <ul className="space-y-2 mb-6 sm:mb-8">
          {features.map((feature, index) => (
            <li key={index} className="flex items-center text-gray-500 group-hover:text-gray-400 transition-colors duration-300">
              <i className="ri-check-line text-green-400 mr-3 text-sm"></i>
              <span className="text-xs sm:text-sm font-light">{feature}</span>
            </li>
          ))}
        </ul>
        
        <Button variant="primary" fullWidth onClick={handleWhatsAppContact}>
          Entrar em Contato
        </Button>
      </div>
    </div>
  );
}

export default function ProductsAllSection() {
  const [activeCategory, setActiveCategory] = useState('barco');

  const categories = [
    { id: 'barco', name: 'Barco', icon: 'ri-ship-line' },
    { id: 'estacionaria', name: 'Estacionária', icon: 'ri-battery-line' },
    { id: 'tracionaria', name: 'Tracionária', icon: 'ri-truck-line' },
    { id: 'efb', name: 'Especiais EFB', icon: 'ri-flashlight-line' },
    { id: 'solar', name: 'Para placa solar', icon: 'ri-sun-line' }
  ];

  const productsByCategory = {
    barco: [
      {
        name: 'Bateria Cunha Náutica 100Ah',
        specs: '12V • 100Ah • 800A',
        features: ['Resistente à corrosão', 'Prova d\'água', 'Garantia 36 meses'],
        image: 'https://readdy.ai/api/search-image?query=marine%20boat%20battery%20with%20blue%20and%20white%20design%2C%20waterproof%20casing%2C%20professional%20product%20photography%20with%20soft%20shadows%20on%20dark%20background%2C%20premium%20nautical%20battery%20for%20boats%2C%20clean%20geometric%20design&width=400&height=400&seq=barco-battery-100ah&orientation=squarish',
        badge: 'Mais Vendido'
      },
      {
        name: 'Bateria Cunha Náutica 120Ah',
        specs: '12V • 120Ah • 950A',
        features: ['Tecnologia AGM', 'Ciclo profundo', 'Garantia 48 meses'],
        image: 'https://readdy.ai/api/search-image?query=marine%20boat%20battery%20with%20navy%20blue%20and%20silver%20design%2C%20waterproof%20casing%2C%20professional%20product%20photography%20with%20soft%20shadows%20on%20dark%20background%2C%20premium%20nautical%20battery%20for%20boats%2C%20clean%20geometric%20design&width=400&height=400&seq=barco-battery-120ah&orientation=squarish'
      },
      {
        name: 'Bateria Cunha Náutica Pro 150Ah',
        specs: '12V • 150Ah • 1200A',
        features: ['Performance superior', 'Uso intensivo', 'Garantia 60 meses'],
        image: 'https://readdy.ai/api/search-image?query=marine%20boat%20battery%20with%20gold%20and%20blue%20design%2C%20waterproof%20casing%2C%20professional%20product%20photography%20with%20soft%20shadows%20on%20dark%20background%2C%20premium%20nautical%20battery%20for%20boats%2C%20clean%20geometric%20design&width=400&height=400&seq=barco-pro-battery-150ah&orientation=squarish',
        badge: 'Premium'
      }
    ],
    estacionaria: [
      {
        name: 'Bateria Cunha Estacionária 45Ah',
        specs: '12V • 45Ah • 400A',
        features: ['Longa duração', 'Baixa manutenção', 'Garantia 24 meses'],
        image: 'https://readdy.ai/api/search-image?query=stationary%20battery%20with%20gray%20and%20green%20design%2C%20industrial%20appearance%2C%20professional%20product%20photography%20with%20soft%20shadows%20on%20dark%20background%2C%20premium%20stationary%20battery%20for%20backup%20power%2C%20clean%20geometric%20design&width=400&height=400&seq=estacionaria-battery-45ah&orientation=squarish',
        badge: 'Mais Vendido'
      },
      {
        name: 'Bateria Cunha Estacionária 60Ah',
        specs: '12V • 60Ah • 500A',
        features: ['Tecnologia VRLA', 'Selada', 'Garantia 36 meses'],
        image: 'https://readdy.ai/api/search-image?query=stationary%20battery%20with%20gray%20and%20orange%20design%2C%20industrial%20appearance%2C%20professional%20product%20photography%20with%20soft%20shadows%20on%20dark%20background%2C%20premium%20stationary%20battery%20for%20backup%20power%2C%20clean%20geometric%20design&width=400&height=400&seq=estacionaria-battery-60ah&orientation=squarish'
      },
      {
        name: 'Bateria Cunha Estacionária Pro 100Ah',
        specs: '12V • 100Ah • 800A',
        features: ['Alta capacidade', 'Uso profissional', 'Garantia 48 meses'],
        image: 'https://readdy.ai/api/search-image?query=stationary%20battery%20with%20gray%20and%20red%20design%2C%20industrial%20appearance%2C%20professional%20product%20photography%20with%20soft%20shadows%20on%20dark%20background%2C%20premium%20stationary%20battery%20for%20backup%20power%2C%20clean%20geometric%20design&width=400&height=400&seq=estacionaria-pro-battery-100ah&orientation=squarish',
        badge: 'Premium'
      }
    ],
    tracionaria: [
      {
        name: 'Bateria Cunha Tração 80Ah',
        specs: '12V • 80Ah • 600A',
        features: ['Ciclo profundo', 'Alta resistência', 'Garantia 30 meses'],
        image: 'https://readdy.ai/api/search-image?query=traction%20battery%20with%20yellow%20and%20black%20design%2C%20heavy%20duty%20appearance%2C%20professional%20product%20photography%20with%20soft%20shadows%20on%20dark%20background%2C%20premium%20traction%20battery%20for%20industrial%20vehicles%2C%20clean%20geometric%20design&width=400&height=400&seq=tracionaria-battery-80ah&orientation=squarish',
        badge: 'Mais Vendido'
      },
      {
        name: 'Bateria Cunha Tração 105Ah',
        specs: '12V • 105Ah • 750A',
        features: ['Tecnologia avançada', 'Máxima durabilidade', 'Garantia 36 meses'],
        image: 'https://readdy.ai/api/search-image?query=traction%20battery%20with%20orange%20and%20black%20design%2C%20heavy%20duty%20appearance%2C%20professional%20product%20photography%20with%20soft%20shadows%20on%20dark%20background%2C%20premium%20traction%20battery%20for%20industrial%20vehicles%2C%20clean%20geometric%20design&width=400&height=400&seq=tracionaria-battery-105ah&orientation=squarish'
      },
      {
        name: 'Bateria Cunha Tração Pro 140Ah',
        specs: '12V • 140Ah • 1000A',
        features: ['Performance extrema', 'Uso intensivo', 'Garantia 48 meses'],
        image: 'https://readdy.ai/api/search-image?query=traction%20battery%20with%20red%20and%20black%20design%2C%20heavy%20duty%20appearance%2C%20professional%20product%20photography%20with%20soft%20shadows%20on%20dark%20background%2C%20premium%20traction%20battery%20for%20industrial%20vehicles%2C%20clean%20geometric%20design&width=400&height=400&seq=tracionaria-pro-battery-140ah&orientation=squarish',
        badge: 'Premium'
      }
    ],
    efb: [
      {
        name: 'Bateria Cunha EFB 60Ah',
        specs: '12V • 60Ah • 640A',
        features: ['Tecnologia EFB', 'Start-Stop', 'Garantia 36 meses'],
        image: 'https://readdy.ai/api/search-image?query=EFB%20battery%20with%20purple%20and%20silver%20design%2C%20modern%20appearance%2C%20professional%20product%20photography%20with%20soft%20shadows%20on%20dark%20background%2C%20premium%20EFB%20battery%20for%20start-stop%20vehicles%2C%20clean%20geometric%20design&width=400&height=400&seq=efb-battery-60ah&orientation=squarish',
        badge: 'Mais Vendido'
      },
      {
        name: 'Bateria Cunha EFB 70Ah',
        specs: '12V • 70Ah • 720A',
        features: ['Alta performance', 'Ciclo melhorado', 'Garantia 42 meses'],
        image: 'https://readdy.ai/api/search-image?query=EFB%20battery%20with%20teal%20and%20silver%20design%2C%20modern%20appearance%2C%20professional%20product%20photography%20with%20soft%20shadows%20on%20dark%20background%2C%20premium%20EFB%20battery%20for%20start-stop%20vehicles%2C%20clean%20geometric%20design&width=400&height=400&seq=efb-battery-70ah&orientation=squarish'
      },
      {
        name: 'Bateria Cunha EFB Pro 80Ah',
        specs: '12V • 80Ah • 800A',
        features: ['Máxima eficiência', 'Tecnologia premium', 'Garantia 48 meses'],
        image: 'https://readdy.ai/api/search-image?query=EFB%20battery%20with%20gold%20and%20silver%20design%2C%20modern%20appearance%2C%20professional%20product%20photography%20with%20soft%20shadows%20on%20dark%20background%2C%20premium%20EFB%20battery%20for%20start-stop%20vehicles%2C%20clean%20geometric%20design&width=400&height=400&seq=efb-pro-battery-80ah&orientation=squarish',
        badge: 'Premium'
      }
    ],
    solar: [
      {
        name: 'Bateria Cunha Solar 100Ah',
        specs: '12V • 100Ah • 800A',
        features: ['Ciclo profundo', 'Energia renovável', 'Garantia 60 meses'],
        image: 'https://readdy.ai/api/search-image?query=solar%20battery%20with%20green%20and%20yellow%20design%2C%20eco-friendly%20appearance%2C%20professional%20product%20photography%20with%20soft%20shadows%20on%20dark%20background%2C%20premium%20solar%20battery%20for%20renewable%20energy%20systems%2C%20clean%20geometric%20design&width=400&height=400&seq=solar-battery-100ah&orientation=squarish',
        badge: 'Mais Vendido'
      },
      {
        name: 'Bateria Cunha Solar 150Ah',
        specs: '12V • 150Ah • 1200A',
        features: ['Alta capacidade', 'Tecnologia AGM', 'Garantia 72 meses'],
        image: 'https://readdy.ai/api/search-image?query=solar%20battery%20with%20blue%20and%20yellow%20design%2C%20eco-friendly%20appearance%2C%20professional%20product%20photography%20with%20soft%20shadows%20on%20dark%20background%2C%20premium%20solar%20battery%20for%20renewable%20energy%20systems%2C%20clean%20geometric%20design&width=400&height=400&seq=solar-battery-150ah&orientation=squarish'
      },
      {
        name: 'Bateria Cunha Solar Pro 200Ah',
        specs: '12V • 200Ah • 1600A',
        features: ['Performance máxima', 'Uso profissional', 'Garantia 84 meses'],
        image: 'https://readdy.ai/api/search-image?query=solar%20battery%20with%20orange%20and%20yellow%20design%2C%20eco-friendly%20appearance%2C%20professional%20product%20photography%20with%20soft%20shadows%20on%20dark%20background%2C%20premium%20solar%20battery%20for%20renewable%20energy%20systems%2C%20clean%20geometric%20design&width=400&height=400&seq=solar-pro-battery-200ah&orientation=squarish',
        badge: 'Premium'
      }
    ]
  };

  const scrollToCategory = (categoryId: string) => {
    setActiveCategory(categoryId);
    const element = document.getElementById(`category-${categoryId}`);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <section className="pt-24 pb-16 sm:pb-24 lg:pb-32 bg-black relative overflow-hidden" data-product-shop="true">
      {/* Background effects */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-1/4 left-1/6 w-96 h-96 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/6 w-96 h-96 bg-gradient-to-r from-blue-600 to-cyan-600 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute top-2/3 left-1/3 w-80 h-80 bg-gradient-to-r from-green-600 to-teal-600 rounded-full blur-3xl animate-pulse"></div>
      </div>
      
      <div className="container mx-auto px-4 sm:px-6 relative z-10">
        <div className="text-center mb-16 sm:mb-24">
          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-thin text-white mb-6 sm:mb-8 tracking-tight">
            Todos os Produtos
          </h1>
          <p className="text-base sm:text-lg md:text-xl text-gray-400 max-w-4xl mx-auto font-light leading-relaxed px-4">
            Explore nossa linha completa de baterias especializadas para todas as suas necessidades
          </p>
        </div>
        
        {/* Category navigation - horizontal layout */}
        <div className="flex justify-center mb-12 sm:mb-20">
          <div className="bg-gray-800/40 backdrop-blur-sm p-2 rounded-full border border-gray-700/30 overflow-x-auto">
            <div className="flex space-x-2">
              {categories.map((category) => (
                <button
                  key={category.id}
                  onClick={() => scrollToCategory(category.id)}
                  className={`px-4 sm:px-6 lg:px-8 py-3 sm:py-4 rounded-full transition-all duration-500 whitespace-nowrap cursor-pointer font-medium text-sm sm:text-base transform hover:scale-105 active:scale-95 ${
                    activeCategory === category.id
                      ? 'bg-white text-black shadow-2xl scale-105'
                      : 'text-gray-400 hover:text-white hover:bg-gray-700/50'
                  }`}
                >
                  <i className={`${category.icon} mr-2 transition-transform duration-500 ${
                    activeCategory === category.id ? 'rotate-12 scale-110' : ''
                  }`}></i>
                  <span>{category.name}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
        
        {/* Categories and products */}
        <div className="space-y-20">
          {categories.map((category) => (
            <div key={category.id} id={`category-${category.id}`} className="scroll-mt-24">
              <div className="text-center mb-12">
                <h2 className="text-3xl sm:text-4xl font-thin text-white mb-4 tracking-tight">
                  <i className={`${category.icon} mr-4`}></i>
                  {category.name}
                </h2>
              </div>
              
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8 lg:gap-10">
                {productsByCategory[category.id as keyof typeof productsByCategory].map((product, index) => (
                  <ProductCard key={index} {...product} />
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Back to home button */}
        <div className="text-center mt-20">
          <Button 
            variant="secondary" 
            onClick={() => window.REACT_APP_NAVIGATE('/')}
          >
            <i className="ri-arrow-left-line mr-2"></i>
            Voltar ao Início
          </Button>
        </div>
      </div>
    </section>
  );
}
